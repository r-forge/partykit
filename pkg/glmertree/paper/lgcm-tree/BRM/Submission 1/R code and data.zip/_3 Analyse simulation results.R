N <- 250
resp <- "Math"

load(paste0("times, N = ", N, ", ", resp, ".RDa"))
load(paste0("MSEs, N = ", N, ", ", resp, ".RDa"))
load(paste0("sizes, N = ", N, ", ", resp, ".RDa"))
load(paste0("notes, N = ", N, ", ", resp, ".RDa"))


colMeans(MSEs, na.rm = TRUE)
boxplot(MSEs, xlab = "MSEs")
colMeans(sizes, na.rm = TRUE)
boxplot(sizes, xlab = "tree sizes")
colMeans(times, na.rm = TRUE)
boxplot(times, xlab = "computation times")


