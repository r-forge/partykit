## Load libraries & save session info
library("glmertree")
library("partykit")
sInfo <- sessionInfo()
save(sInfo, file = "sessionInfo.Rda")

## Set up design
methods <- c("LMtree_c", "LMMtree", "LMMtree_c", "LMMtree_r", "LMMtree_cr",
             "LMMtree_sc", "LMMtree_sr", "LMMtree_scr")
Ns <- 250
nreps <- 100L

## Prepare formulas
LM_form <- score ~ months | GENDER + RACE + WKSESL + C1GMOTOR + 
  C1FMOTOR + T1INTERN + T1EXTERN + T1INTERP + T1CONTRO + P1FIRKDG + AGEBASELINE
LMM_form <- score ~ months | CHILDID | GENDER + RACE + WKSESL + C1GMOTOR + 
  C1FMOTOR + T1INTERN + T1EXTERN + T1INTERP + T1CONTRO + P1FIRKDG + AGEBASELINE
LMM_s_form <- score ~ months | ((1 + months) | CHILDID) | GENDER + RACE + WKSESL + 
  C1GMOTOR + C1FMOTOR + T1INTERN + T1EXTERN + T1INTERP + T1CONTRO + P1FIRKDG + 
  AGEBASELINE

set.seed(42)
for (resp in c("Math", "Reading", "Science")) {
  
  ## Read in data and prepare objects for saving results
  load(paste0(resp, " ability data.Rdata"))
  resp_short <- ifelse(resp == "Math", "math", ifelse(resp == "Reading", "read", "scie"))
  data <- get(paste0(resp_short, "data"))

  data$CHILDID <- factor(data$CHILDID)
  data$GENDER <- factor(data$GENDER)
  data$asmtmm <- factor(data$asmtmm)
  sizes <- data.frame(matrix(NA, nrow = nreps, ncol = length(methods),
                             dimnames = list(1:nreps, methods)))
  notes <- MSEs <- times <- sizes
  
  for (N in Ns) {
    
    ## Generate samples for each repetition
    bag_ids <- sapply(1:nreps, function(x) sample(unique(data$CHILDID), size = N))
    save(bag_ids, file = paste0("bag_ids, N = ", N, ", ", resp, ".Rda"))
    
    for (i in 1:nreps) {
      
      print(paste("Fold", i))
      
      ## Set up train and test data  
      train <- data[data$CHILDID %in% bag_ids[ , i], ]
      test <- data[!data$CHILDID %in% bag_ids[ , i], ]
      ## Remove obs with levels of race in test are also in train
      levs <- unique(test$RACE) %in% unique(train$RACE)
      if (!all(levs)) {
        test <- test[-which(!test$RACE %in% unique(test$RACE)[levs]), ]
        notes[i, ] <- paste0(notes[i, ], 
                             "Levels or race omitted from test data: ", 
                             unique(test$race)[!levs])
      }
      
      
      ## Fit LM trees
      
      times$LMtree_c[i] <- system.time(
        tree <- lmtree(LM_form, data = train, cluster = CHILDID, 
                       maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test)
      MSEs$LMtree_c[i] <- mean((test$score - preds)^2) 
      sizes$LMtree_c[i] <- (length(tree)-1)/2

      
      
      ## Fit LMM trees
      
      times$LMMtree[i] <- system.time(
        tree <- lmertree(LMM_form, data = train, maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree[i] <- (length(tree$tree)-1)/2
            
      times$LMMtree_c[i] <- system.time(
        tree <- lmertree(LMM_form, data = train, cluster = CHILDID, 
                         maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree_c[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree_c[i] <- (length(tree$tree)-1)/2

      times$LMMtree_r[i] <- system.time(
        tree <- lmertree(LMM_form, data = train, ranefstart = TRUE, 
                         maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree_r[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree_r[i] <- (length(tree$tree)-1)/2
      
      times$LMMtree_cr[i] <- system.time(
        tree <- lmertree(LMM_form, data = train, cluster = CHILDID, 
                         ranefstart = TRUE, maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree_cr[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree_cr[i] <- (length(tree$tree)-1)/2
      
      times$LMMtree_sc[i] <- system.time(
        tree <- lmertree(LMM_s_form, data = train, cluster = CHILDID, 
                         maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree_sc[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree_sc[i] <- (length(tree$tree)-1)/2
      
      times$LMMtree_sr[i] <- system.time(
        tree <- lmertree(LMM_s_form, data = train, ranefstart = TRUE, 
                         maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree_sr[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree_sr[i] <- (length(tree$tree)-1)/2
      
      times$LMMtree_scr[i] <- system.time(
        tree <- lmertree(LMM_s_form, data = train, cluster = CHILDID, 
                         ranefstart = TRUE, maxdepth = 6))["elapsed"]
      preds <- predict(tree, newdata = test, re.form = NA)
      MSEs$LMMtree_scr[i] <- mean((test$score - preds)^2) 
      sizes$LMMtree_scr[i] <- (length(tree$tree)-1)/2
      
      ## Save results (overwrites in each replication to prevent loss of results)
      save(times, file = paste0("times, N = ", N, ", ", resp, ".Rda"))
      save(MSEs, file = paste0("MSEs, N = ", N, ", ", resp, ".Rda"))
      save(sizes, file = paste0("sizes, N = ", N, ", ", resp, ".Rda"))
      save(notes, file = paste0("notes, N = ", N, ", ", resp, ".Rda"))
    }
  }
}